/**
 * 
 */
/**
 * 
 */
module GestionTriSelectif {
    requires java.sql;
}