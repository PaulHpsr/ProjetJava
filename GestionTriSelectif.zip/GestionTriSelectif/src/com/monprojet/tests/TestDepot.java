package com.monprojet.tests;
import java.time.LocalDateTime;

import com.monprojet.classes.Depot;
//import com.monprojet.classes.TypeDechet;
import com.monprojet.classes.Dechet;
//import java.util.ArrayList;
//import com.monprojet.tests.TestDechet;

public class TestDepot {
	
	public static void afficherInfo(Depot dep){
		System.out.println("id du dépot : "+ dep.getId());
		System.out.println("heure de dépot : "+ dep.getHeureDepot());
		System.out.println("Liste de déchets qui composent le dépot : ");
		for (Dechet dech:dep.getListeDechet()) {
			TestDechet.afficherInfo(dech);
		}
	}
	
	
	public static void main(String[] args) {
		
		Depot dep1=new Depot();
		LocalDateTime d = LocalDateTime.of(1990, 1, 1, 8, 50);
		Depot dep2=new Depot(d);

		
		Dechet dech=new Dechet(1);
		Dechet dech2=new Dechet(3);
		dep1.ajouter(dech);
		dep1.ajouter(dech2);
		
		afficherInfo(dep1);
		
		System.out.println(" ");
		afficherInfo(dep2);
		System.out.println(dep1.toString());
	
	}
}
