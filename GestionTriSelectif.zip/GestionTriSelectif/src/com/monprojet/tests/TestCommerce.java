package com.monprojet.tests;
import com.monprojet.classes.Commerce;




public class TestCommerce {

	
	public static void afficherInfo(Commerce commerce){
		System.out.println("Id : "+ commerce.getId());
		System.out.println("Nom : "+ commerce.getNom());
		System.out.println("Liste Rapport : "+ commerce.getRapportConversion());
	}
	
	
	public static void main(String[] args) 
	{
        // créa commerce
		
        Float rapportConversion = (float) 0.1 ; 
        Commerce commerce = new Commerce("Auchan", rapportConversion);

        afficherInfo(commerce);
        System.out.println(commerce.toString());
	}
}
