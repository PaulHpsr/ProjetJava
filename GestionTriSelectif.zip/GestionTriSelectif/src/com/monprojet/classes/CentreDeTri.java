package com.monprojet.classes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import dataBase.InsertionCentreDeTri;
import dataBase.InsertionPoubelleIntelligente;


public class CentreDeTri {
	
	/* Attributs */
	private static int compteur;
	private int id;
	private String nom;
	private String adresse;
	//private int nbPoubelle;
	//private String histroriqueStatistiques;
	private ArrayList<PoubelleIntelligente> listePoubelle;
	private HashMap<Integer,ArrayList<Depot>> historiqueDepot; //L'entier correspond à un id d'une poubelle et la liste de dépot correspond aux dépots faits dans cette poubelle. On a ainsi un historique de dépot par poubelle
	
	/* Méthodes */

	public void ajouter(String emplacement,int type) {
		int[] pasDeDechets=new int[4]; //les poubelles ajoutées au centre de tri sont vide par defaut
		// en fonction du type de la poubelle on specifie les capaMax
		switch (type) {
			case 0:
				int[] capa0= {5,1,1,1};
				PoubelleIntelligente poubelle0=new PoubelleIntelligente(emplacement,type,pasDeDechets,capa0);
				this.listePoubelle.add(poubelle0);
				InsertionPoubelleIntelligente.updatePoubelleIntelligente(poubelle0, this);
				break;
			case 1:
				int[] capa1= {1,5,1,1};
				PoubelleIntelligente poubelle1=new PoubelleIntelligente(emplacement,type,pasDeDechets,capa1);
				this.listePoubelle.add(poubelle1);
				InsertionPoubelleIntelligente.updatePoubelleIntelligente(poubelle1, this);
				break;
			case 2:
				int[] capa2= {1,1,5,1};
				PoubelleIntelligente poubelle2=new PoubelleIntelligente(emplacement,type,pasDeDechets,capa2);
				this.listePoubelle.add(poubelle2);
				InsertionPoubelleIntelligente.updatePoubelleIntelligente(poubelle2, this);
				break;
			case 3:
				int[] capa3= {1,1,1,5};
				PoubelleIntelligente poubelle3=new PoubelleIntelligente(emplacement,type,pasDeDechets,capa3);
				this.listePoubelle.add(poubelle3);
				InsertionPoubelleIntelligente.updatePoubelleIntelligente(poubelle3, this);
				break;
		// D'après la définition de la classe PoubelleIntelligente on se retrouvera forcément dans l'un des 4 cas ci-dessus car le type de la poubelle appartient à {0,1,2,3}
		}
		
	}
	public void retirer(int id) {
	    boolean trouve = false;
	    
	    // Utilisation d'un Iterator pour éviter ConcurrentModificationException
	    Iterator<PoubelleIntelligente> it = this.getListePoubelle().iterator();
	    
	    while (it.hasNext()) {
	        PoubelleIntelligente poubelle = it.next();
	        if (poubelle.getId() == id) {
	            it.remove(); // Suppression sécurisée
	            InsertionPoubelleIntelligente.supprimerPoubelleIntelligente(poubelle);
	            trouve = true;
	            break; // On sort dès qu'on a supprimé l'élément
	        }
	    }
	    
	    if (!trouve) {
	        System.out.println("La poubelle est déjà supprimée ou l'ID ne correspond à aucune poubelle.");
	    }
	}
	/*
	public void collecter(int id) {
		boolean trouve=false;
		for(PoubelleIntelligente poubelle: this.getListePoubelle() ) {
			if(poubelle.getId()==id) {
				poubelle.viderPoubelle();
				trouve=true;
			}
		}
		if(!(trouve)) {System.out.print("la poubelle n'est pas rattachée au centredetri");}
	}
	*/
	public void collecter(int id) {
		boolean trouve=false;
		
		for(PoubelleIntelligente poubelle: this.getListePoubelle() ) {			
			if(poubelle.getId()==id) {
				trouve=true;
				// Créer une nouvelle liste pour stocker les dépôts dans l'historique
            	ArrayList<Depot> arrayListeDepots = new ArrayList<>(poubelle.getListeDepot());
				if(historiqueDepot.containsKey(id)){
						historiqueDepot.get(id).addAll(arrayListeDepots);
				}
				
				else{
					historiqueDepot.put(id, arrayListeDepots);
					/*for (Depot dep: poubelle.getListeDepot()) {
						historiqueDepot.get(id).add(dep);
					}*/
				}
				poubelle.viderListeDepot();
				InsertionPoubelleIntelligente.updateEtat(poubelle);
				break;
			}						
		}
		if(!(trouve)) {
			System.out.print("la poubelle n'est pas rattacher au centredetri");
		}
	}
	
	public void collecteGenerale() {
		for (PoubelleIntelligente poub:getListePoubelle()) {
			if(poub.estPlein()) {
				this.collecter(poub.getId());
			}
		}
	}
	
	public void deplacer(PoubelleIntelligente poubelle, String nouvelleAdresse) {
		poubelle.setEmplacement(nouvelleAdresse);
		InsertionPoubelleIntelligente.updateEmplacement(poubelle);
	}
	
	
	public void calculerStatistiques() {
		//Calcul du nombre moyen de déchet par dépot
		System.out.println("Calcul de quelques données statistiques : ");
		int compteurDepot=0;
		int compteurDechet=0;
		for (ArrayList<Depot> listeDepot:historiqueDepot.values()) {
			for (Depot dep:listeDepot) {
				compteurDepot++;
				compteurDechet=compteurDechet+dep.getListeDechet().size();
			}
		}
		System.out.println("\t Il y a en moyenne " + ((float) compteurDechet/(float) compteurDepot) + " déchets par dépot");
		
		//Calcul du nombre moyen de dépots par poubelle
		System.out.println("\t Il y a en moyenne " + ((float) compteurDepot/(float) historiqueDepot.keySet().size()) + " dépôts par poubelle");
		
	}

	
	public void fairePrediction() {}


	// Setter & getter
	
	public	int getId() {
		return id;
	}
	
	public String getNom() {
		return nom;
	}
	public String getAdresse() {
		return adresse;
	}
	public ArrayList<PoubelleIntelligente> getListePoubelle() {
		return listePoubelle;
	}
	public String toString(){
		String listePoubelle="";
		if (!getListePoubelle().isEmpty()) {
			for (PoubelleIntelligente poubelle:getListePoubelle()) {
				listePoubelle=listePoubelle+poubelle.toString()+" , \n";
			}
			return "( Id du Centre de Tri : "+getId()+ ", Nom du Centre de Tri : " +getNom()+", Adresse du centre de Tri : "+getAdresse()+",\n Liste des poubelles : \n"+listePoubelle.substring(0, listePoubelle.length() - 2)+"\n Historique des depots : \n"+toStringHistoriqueDepot()+")";
		}else{
			return "( Id du Centre de Tri : "+getId()+ ", Nom du Centre de Tri : " +getNom()+", Adresse du centre de Tri : "+getAdresse()+", Liste des poubelles : VIDE"+"\n Historique des depots : \n"+toStringHistoriqueDepot()+")";
		}
	}
	
	public String toStringHistoriqueDepot() {
		String hist = "";
		int i=0;
		for(Integer key : historiqueDepot.keySet()){
			if (i==0) {
				hist = hist +"\t id Poubelle : "+key + ", Dépots pour cette poubelle :";
				i++;
			}
			else {
				hist = hist +"\n\t id Poubelle : "+key + ", Dépots pour cette poubelle :";
			}
			for(Depot dep:historiqueDepot.get(key)) {
				hist=hist + dep.toString()+",";
			}
		}
		return hist;
	}
	
	public PoubelleIntelligente getPoubelleById(int id) {
		
		for(PoubelleIntelligente poub: this.getListePoubelle() ) {
			if(id==poub.getId()){
				return poub;
			}
		}
		throw new IllegalArgumentException("La poubelle d'id "+id+" n'existe pas");
	}

	// Constructeurs
	
	public CentreDeTri(String nom,String adresse) {
		this.id=++compteur;
		this.nom=nom;
		this.adresse=adresse;
		this.listePoubelle=new ArrayList<>();
		this.historiqueDepot = new HashMap<Integer,ArrayList<Depot>>();
		InsertionCentreDeTri.insererCentreDeTri(this);
	}
	
	public CentreDeTri(String nom,String adresse,ArrayList<PoubelleIntelligente> l) {
		this.id=++compteur;
		this.nom=nom;
		this.adresse=adresse;
		this.listePoubelle=l;
		this.historiqueDepot = new HashMap<Integer,ArrayList<Depot>>();
		InsertionCentreDeTri.insererCentreDeTri(this);
	}
	public CentreDeTri(HashMap<Integer, ArrayList<Depot>> historiqueDepot) {
		this.id=++compteur;
		this.nom="Test";
		this.adresse="Test";
		this.listePoubelle=new ArrayList<>();
		this.historiqueDepot = historiqueDepot;
		InsertionCentreDeTri.insererCentreDeTri(this);
	}
	
} 
	

