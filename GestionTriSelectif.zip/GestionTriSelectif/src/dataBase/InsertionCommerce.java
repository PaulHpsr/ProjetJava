package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.monprojet.classes.Commerce;

public class InsertionCommerce {
	
	/* Attributs */
	
	private static final String URL = "jdbc:mysql://localhost:3306/gestiontri?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
	/* Méthodes */
    
	public static void insererCommerce(Commerce commerce) {
		String sql = "INSERT INTO Commerce (id,nom) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Remplissage des paramètres
            pstmt.setInt(1, commerce.getId());
            pstmt.setString(2, commerce.getNom());

            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Commerce inséré avec succès !");                
            }
        } 
        catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
	}
}

