package dataBase;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.monprojet.classes.ContratPartenariat;

public class InsertionContratPartenariat {
	
	/* Attributs */
	
	private static final String URL = "jdbc:mysql://localhost:3306/gestiontri?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
	/* Méthodes */
    
	public static void insererContratPartenariat(ContratPartenariat contrat) {
		String sql = "INSERT INTO ContratPartenariat (id,idCommerce,idCentreDeTri,dateDebut,dateFin,conditions,categoriesProduits) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Remplissage des paramètres
            pstmt.setInt(1, contrat.getId());
            pstmt.setInt(2, contrat.getCommerce().getId());
            pstmt.setInt(3, contrat.getCentreDeTri().getId());
            pstmt.setDate(4, Date.valueOf(contrat.getDateDebut()));
            pstmt.setDate(5, Date.valueOf(contrat.getDateFin()));
            pstmt.setString(6, contrat.getCondition());
            pstmt.setString(7, contrat.getCategoriesProduits());

            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("ContratPartenariat inséré avec succès !");                
            }
        } 
        catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
	}
	
	
	public static void updateContratPartenariat(ContratPartenariat contrat) {
	    String sql = "UPDATE ContratPartenariat SET dateFin = ?, conditions=?,categoriesProduits = ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {  

	        // Remplissage des paramètres
	        pstmt.setDate(1, Date.valueOf(contrat.getDateFin()));   
	        pstmt.setString(2, contrat.getCondition());
            pstmt.setString(3, contrat.getCategoriesProduits());
	        pstmt.setInt(4, contrat.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("ContratPartenariat mis à jour avec succès !");
	        } else {
	            System.out.println("Aucun ContratPartenariat trouvé avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
}
