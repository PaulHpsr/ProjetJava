package dataBase;

import com.monprojet.classes.*;
import java.sql.*;


public class InsertionDechet {
	
	/* Attributs */
	
	private static final String URL = "jdbc:mysql://localhost:3306/gestiontri?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
	/* Méthodes */
	
	public static void insererDechet(Dechet dechet) {
		String sql = "INSERT INTO Dechet (typeDechet,categorie,poids) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Remplissage des paramètres
            pstmt.setInt(1, dechet.getType());
            pstmt.setString(2, dechet.getCategorie().toString());
            pstmt.setInt(3, dechet.getPoids());

            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Déchet inséré avec succès !");                
            }
        } 
        catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
	}
	
	
	public static void updateDechet(Dechet dechet, Depot depot) {
	    String sql = "UPDATE Dechet SET idDepot = ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {  // Pas besoin de RETURN_GENERATED_KEYS

	        // Remplissage des paramètres
	        pstmt.setInt(1, depot.getId());   // Précise que le déchet a été fait dans un certain dépôt
	        pstmt.setInt(2, dechet.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Déchet mis à jour avec succès !");
	        } else {
	            System.out.println("Aucun déchet trouvé avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	
	
}