package dataBase;

import com.monprojet.classes.*;
import java.sql.*;
import java.time.format.DateTimeFormatter;


public class InsertionDepot {
	
	/* Attributs */
	
	private static final String URL = "jdbc:mysql://localhost:3306/gestiontri?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
	/* Méthodes */
	
	public static void insererDepot(int idPoubelle, int idMenage,Depot depot) {
		String sql = "INSERT INTO Depot (id,idPoubelle, idMenage, heureDepot, pointsGagnes) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Formatage de la date pour SQL
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String heureDepotSQL = depot.getHeureDepot().format(formatter);

            // Remplissage des paramètres
            pstmt.setInt(1, depot.getId());
            pstmt.setInt(2, idPoubelle);
            pstmt.setInt(3, idMenage);
            pstmt.setString(4, heureDepotSQL);
            pstmt.setInt(5, depot.getPointsGagnes());

            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Dépôt inséré avec succès !");
                
                // Récupérer l'ID généré
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        depot.setId(generatedKeys.getInt(1)); // Mise à jour de l'ID de l'objet
                        System.out.println("ID du dépôt généré : " + depot.getId());
                    }
                }
            }

        } catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
		
	}
	
	public static void updateDepot(Depot depot) {
	    String sql = "UPDATE Depot SET pointsGagnes = ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {  // Pas besoin de RETURN_GENERATED_KEYS

	        // Remplissage des paramètres
	        pstmt.setInt(1, depot.getPointsGagnes());   // Associe la poubelle à son centre de tri
	        pstmt.setInt(2, depot.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Dépôt mise à jour avec succès !");
	        } else {
	            System.out.println("Aucun dépôt trouvé avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
}
