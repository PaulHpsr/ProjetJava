package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import com.monprojet.classes.CentreDeTri;
import com.monprojet.classes.PoubelleIntelligente;

public class InsertionPoubelleIntelligente {
	/* Attributs */
	
	private static final String URL = "jdbc:mysql://localhost:3306/gestiontri?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
	/* Méthodes */
    
	public static void insererPoubelleIntelligente(PoubelleIntelligente poubelle) {
		String sql = "INSERT INTO PoubelleIntelligente (id,emplacement,typePoub,etat) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Remplissage des paramètres
            pstmt.setInt(1, poubelle.getId());
            pstmt.setString(2, poubelle.getEmplacement());
            pstmt.setInt(3, poubelle.getTypePoub());
            pstmt.setBoolean(4, poubelle.getEtat());

            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Poubelle insérée avec succès !");                
            }
        } 
        catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
	}
	
	public static void supprimerPoubelleIntelligente(PoubelleIntelligente poubelle) {
		String sql = "DELETE FROM PoubelleIntelligente WHERE id = ? ";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Remplissage des paramètres
            pstmt.setInt(1, poubelle.getId());
    
            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Poubelle supprimée avec succès !");                
            }
        } 
        catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
	}
	
	public static void updatePoubelleIntelligente(PoubelleIntelligente poubelle, CentreDeTri centre) {
	    String sql = "UPDATE PoubelleIntelligente SET idCentreDeTri = ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {  

	        // Remplissage des paramètres
	        pstmt.setInt(1, centre.getId());   //On associe la poubelle à son centre de tri
	        pstmt.setInt(2, poubelle.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Poubelle mise à jour avec succès !");
	        } else {
	            System.out.println("Aucune poubelle trouvée avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	public static void updateEmplacement(PoubelleIntelligente poubelle) {
	    String sql = "UPDATE PoubelleIntelligente SET emplacement= ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) { 

	        // Remplissage des paramètres
	        pstmt.setString(1, poubelle.getEmplacement());   
	        pstmt.setInt(2, poubelle.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Poubelle mise à jour avec succès !");
	        } else {
	            System.out.println("Aucune poubelle trouvée avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	
	public static void updateEtat(PoubelleIntelligente poubelle) {
	    String sql = "UPDATE PoubelleIntelligente SET etat= ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) { 

	        // Remplissage des paramètres
	        pstmt.setBoolean(1, poubelle.getEtat());   
	        pstmt.setInt(2, poubelle.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Poubelle mise à jour avec succès !");
	        } else {
	            System.out.println("Aucune poubelle trouvée avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
}
