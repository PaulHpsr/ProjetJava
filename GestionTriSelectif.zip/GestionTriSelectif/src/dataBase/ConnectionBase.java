package dataBase;

import java.sql.*;

public class ConnectionBase {
    public static void main(String[] args) {
        // Paramètres de connexion
        String url = "jdbc:mysql://localhost:3306/gestiontri"; // Remplacez par le nom de votre BDD
        String user = "root"; // Remplacez par votre utilisateur
        String password = ""; // Remplacez par votre mot de passe

        // Connexion à la base de données
        try {
            // Charger le driver JDBC (non obligatoire avec les versions récentes)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Établir la connexion
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion réussie à la base de données !");

            // Création d'une requête SQL
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM menage");

            // Parcourir les résultats
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Nom: " + rs.getString("nom") + ", CodeAcces: "+rs.getInt("codeacces")+", PointFidel: "+rs.getInt("pointfidel"));
            }

            // Fermer les ressources
            rs.close();
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException e) {
            System.err.println("Erreur : Driver JDBC non trouvé !");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
    }
}

