package dataBase;

import java.sql.*;


import com.monprojet.classes.Menage;

public class InsertionMenage {
    private static final String URL = "jdbc:mysql://localhost:3306/gestiontri?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
	/* Méthodes */
	public static void insererMenage(Menage menage) {
		String sql = "INSERT INTO Menage (id,nom,codeAcces,pointFidel) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Remplissage des paramètres
            pstmt.setInt(1, menage.getId());
            pstmt.setString(2, menage.getNom());
            pstmt.setInt(3, menage.getCodeAcces());
            pstmt.setInt(4, menage.getPointFidel());

            // Exécution de la requête
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Ménage inséré avec succès !");
            }

        } catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
    }
    public static void updateMenage(Menage menage) {
	    String sql = "UPDATE Menage SET pointFidel = ? WHERE id = ?";

	    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {  // Pas besoin de RETURN_GENERATED_KEYS

	        // Remplissage des paramètres
	        pstmt.setInt(1, menage.getPointFidel());  
	        pstmt.setInt(2, menage.getId());  // Condition WHERE

	        // Exécution de la requête
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Poubelle mise à jour avec succès !");
	        } else {
	            System.out.println("Aucune poubelle trouvée avec cet ID.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Erreur SQL : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
    
    
    
    
    
    
    
    
    
    
    
}
